#!/bin/sh
CERV_DIR=/usr/share/cervantes
xterm -title "Login Server" -bg black -fg white -hold -e $CERV_DIR/scripts/start_login_server.sh &
sleep 1
xterm -title "Char Server" -bg black -fg white -hold -e $CERV_DIR/scripts/start_char_server.sh &
sleep 1
xterm -title "Map Server" -bg black -fg white -hold -e $CERV_DIR/scripts/start_map_server.sh &
